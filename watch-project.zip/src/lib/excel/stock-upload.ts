import * as XLSX from 'xlsx';

export const requiredHeaders = [
  'Brand',
  'Model',
  'Reference Number',
  'Serial Number',
  'Material',
  'Dial Color',
  'Bracelet Type',
  'Date Received',
  'Status'
] as const;

export type ParsedStockRow = {
  rowNumber: number;
  brand: string;
  model: string;
  referenceNumber: string;
  serialNumber: string;
  material: string;
  dialColor: string;
  braceletType: string;
  dateReceived: string;
  status: string;
};

export function parseStockWorkbook(buffer: Buffer): ParsedStockRow[] {
  const workbook = XLSX.read(buffer, { type: 'buffer' });
  const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: '' });

  const headers = Object.keys(rows[0] || {});
  const missingHeaders = requiredHeaders.filter((header) => !headers.includes(header));
  if (missingHeaders.length) {
    throw new Error(`Missing required columns: ${missingHeaders.join(', ')}`);
  }

  return rows.map((row, index) => ({
    rowNumber: index + 2,
    brand: String(row['Brand'] || '').trim(),
    model: String(row['Model'] || '').trim(),
    referenceNumber: String(row['Reference Number'] || '').trim(),
    serialNumber: String(row['Serial Number'] || '').trim(),
    material: String(row['Material'] || '').trim(),
    dialColor: String(row['Dial Color'] || '').trim(),
    braceletType: String(row['Bracelet Type'] || '').trim(),
    dateReceived: String(row['Date Received'] || '').trim(),
    status: String(row['Status'] || '').trim(),
  }));
}
